(Original text)
Enjoy this pack of stupid sounds for use as tf2 hitsounds. The OuhNo! Hitsound (and maybe others) might not actually work as I compiled them as the wrong format of .wav ...I think. Let me know and I can update this pack eventually.



Place the hitsound.wav in a location such as C:\Steam\steamapps\common\Team Fortress 2\tf\custom\HITSOUNDS\sound\ui

"HITSOUNDS" can be named anything




I keep all the hitsounds in .rar so they can be easily extracted at any time to overwrite the current hitsound.wav in the folder without permanently losing any files.


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Leo_ 07/03/2015 (dd/mm/yyyy) [UPDATE 1 OF SOUNDPACK]
--sup guys and gals--

-Added "ITS OVER" hitsound from Star_'s video, "What Really Happened?" (around 1:20ish)


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
If you have any suggestions for more hitsounds, just comment and I'll get around to it!
	Leo_